function startHandler (){
    document.addEventListener('scroll', ()=> {
        let btn=document.getElementById('btn');
        let navbar=document.getElementById('navbar');
        let verticalPoint= btn.offsetTop; //dammi distanza del button da sopra
        let scrollPoint= document.documentElement.scrollTop; //distanza da sopra della scroll bar
        if(scrollPoint>verticalPoint){
            navbar.style.backgroundColor= 'red';
        }
        else{
    navbar.style.backgroundColor= '#ffc017';
        }
    })
}
window.onload=startHandler;